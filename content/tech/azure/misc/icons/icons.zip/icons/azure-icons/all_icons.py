import os

EXTENTIONS = ('.png', '.svg', '.jpg')

def normalize_path(path):
    return path.replace(os.sep, '/').lstrip('./')

print('<html><head><title>Azure Icons</title></head><body>')

for dirpath, dirs, files in os.walk('.'):
    print('<div style="font-weight: bold;">' + normalize_path(dirpath) + '</div>')
    for f in files:
        path = os.path.join(dirpath, f)
        if not path.endswith(EXTENTIONS):
            continue
        path = path.replace(os.sep, '/')
        print('<img style="width:30px" src="{}" alt="{}">'.format(path, path))

print('</body></html>')

